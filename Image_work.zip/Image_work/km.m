C=imread('cherry.png');
C1=kmean(C,0,5)
imshow(C1);