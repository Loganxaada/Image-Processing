function varargout = gui(varargin)
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 04-Nov-2021 16:13:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,filepath] = uigetfile({'*.bmp;*.jpg;*.tif;*.jpeg;*.png',...
    '�ļ�����(*.bmp,*.jpg,*.tif,*.jpeg,*.png)';'*.*','�����ļ�(*.*)'});
file = strcat(filepath,filename);
global I;
I = imread(file);
axes(handles.axes1);
imshow(I),title('ԭͼ');


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
x=rgb2gray(I);
axes(handles.axes2);
imshow(x),title('�Ҷ�ͼ');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
r = get(hObject,'Value');
global I;
%R = imrotate(I,r,'


% --- Executes on selection change in op.
function op_Callback(hObject, eventdata, handles)
% hObject    handle to op (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns op contents as cell array
%        contents{get(hObject,'Value')} returns selected item from op
choice = get(hObject,'Value');
global I;
if choice == 1
    x=rgb2gray(I);
    axes(handles.axes2);
    imshow(x),title('�Ҷ�ͼ');
else 
    if choice == 2
        h=imhist(rgb2gray(I));
        axes(handles.axes2);
        bar(h),title('ֱ��ͼ');
    end
    if choice == 3
        h = histeq(rgb2gray(I));
        axes(handles.axes2);
        imshow(h),title('ֱ��ͼ���⻯');
    end
end

% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
v = get(hObject,'Value');
global I;
A = imadd(I,v);
axes(handles.axes2);
imshow(A),title('���ȵ��ں�');



% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sobel_Callback(hObject, eventdata, handles)
% hObject    handle to sobel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
I1 = rgb2gray(I);
BW1=edge(I1,'sobel');
axes(handles.axes2);
imshow(BW1),title('sobel���ӱ�Ե��ⷨ');

% --------------------------------------------------------------------
function prewitt_Callback(hObject, eventdata, handles)
% hObject    handle to prewitt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
BW1=edge(rgb2gray(I),'prewitt');
axes(handles.axes2);
imshow(BW1),title('Prewitt���ӱ�Ե��ⷨ');

% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1
global I;
if(get(hObject,'Value' )== 0)
    msgbox('��ѡ��ͼƬ');
else
    [filename,filepath] = uigetfile({'*.bmp;*.jpg;*.tif;*.jpeg',...
        '�ļ�����(*.bmp,*.jpg,*.tif,*.jpeg)';'*.*','�����ļ�(*.*)'});
    file = strcat(filepath,filename);
    
    I = imread(file);
    axes(handles.axes1);
    imshow(I),title('ԭͼ');
end

% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2
list = get(hObject,'Value');
global I;
if list == 1
    se = translate(strel(1), [50 140]);%��һ��ƽ��ṹ��Ԫ�طֱ����º������ƶ�30��λ��
    J = imdilate(I,se);%�������ͺ���ƽ��ͼ��
    %subplot(121);imshow(I), title('ԭͼ')
    axes(handles.axes2);
    imshow(J), title('ƽ�ƺ��ͼ��');
else
    if list == 2 
        h_shuiping=flipdim(I,1);
        axes(handles.axes2);
       imshow(h_shuiping),title('ˮƽ����'); 
       %subplot(2,2,3),imshow(h_chuizhi),title('��ֱ����');
    end
    if list == 3
        h_chuizhi=flipdim(I,2);
        axes(handles.axes2);
        imshow(h_chuizhi),title('��ֱ����');
    end
    if list == 4
        tform=affine2d([1 0 0;.5 1 0; 0 0 1]);
        S=imwarp(I,tform);
        axes(handles.axes2);
        imshow(S),title('����');
    end
    if list == 5
        %f= imread('ts.png');
        axes(handles.axes1);
        imshow(I),title('ԭͼ')
        fprintf('Begin to choose the color chip')
        choose=true;
        while choose
            imshow(I)
            dot=ginput(4);       %ȡ�ĸ��㣬���������ϣ����£�����,����
            y=[dot(1,1),dot(2,1),dot(3,1),dot(4,1)];        %�ĸ�ԭ����
            x=[dot(1,2),dot(2,2),dot(3,2),dot(4,2)];
            plot_x=[x,x(1)];
            plot_y=[y,y(1)];
            hold on
            plot(plot_y,plot_x,'r','LineWidth',2)
            hold off
            fprintf('Do you satisfy the target you chosen ,press 0 to rechose or press anything else to go\n');
            a=input('');
            if a~=0
                choose=false;
            end
        end
        w=round(max(dot(:,1))-min(dot(:,1)));
        h=round(max(dot(:,2))-min(dot(:,2)));
        %��ԭ�ı��λ���¾��θ�
        
        %�������µĶ��㣬��ȡ�ľ���,Ҳ����������������״
        %�����ԭͼ���Ǿ��Σ���ͼ���Ǵ�dot��ȡ�õĵ���ɵ������ı���.:)
        Y=[1,1,w,w];
        X=[1,h,h,1];
        
        B=[X(1),Y(1),X(2),Y(2),X(3),Y(3),X(4),Y(4)]';   %�任����ĸ����㣬�����ұߵ�ֵ
        %�����ⷽ���飬���̵�ϵ��
        A=[x(1),y(1),1,0,0,0,-X(1)*x(1),-X(1)*y(1);
            0,0,0,x(1),y(1),1,-Y(1)*x(1),-Y(1)*y(1);
            x(2),y(2),1,0,0,0,-X(2)*x(2),-X(2)*y(2);
            0,0,0,x(2),y(2),1,-Y(2)*x(2),-Y(2)*y(2);
            x(3),y(3),1,0,0,0,-X(3)*x(3),-X(3)*y(3);
            0,0 ,0,x(3),y(3),1,-Y(3)*x(3),-Y(3)*y(3);
            x(4),y(4),1,0,0,0,-X(4)*x(4),-X(4)*y(4);
            0,0,0,x(4),y(4),1,-Y(4)*x(4),-Y(4)*y(4)];%���任���������ʽ
        cut_picture=zeros(h,w);
        OutPicture=zeros(h,w,3);
        OutPicture=cast(OutPicture,'uint8');%���ͱ任Ϊuint8
        fa=inv(A)*B;
        fa=reshape([fa;1],[3,3]);%fa���Ǳ任����
        cut=zeros(h+1,w+1);
        BW=roipoly(I,y,x);%������ѡ������Ķ�ֵ��ͼ��cut
        [coordinate_x,coordinate_y]=find(BW==1);%���ѡ�����������λ��
        coordinate=[coordinate_x,coordinate_y,ones(length(coordinate_y),1)];%����z=1ֵ�Ա������߱任
        cut=coordinate*fa;%��������仯
        cut(:,1)=cut(:,1)./cut(:,3);
        cut(:,2)=cut(:,2)./cut(:,3);%���ͼ���϶�Ӧ��x��yֵ
        cut=floor(cut+eps);
        cut(find(cut(:,1:2)==0))=1;%�߽�Ϊ��ĵ��Ϊ1��
        cut_coordinate=cut(:,1:2);%��ñ任�������λ��
        for k=1:3
            img=I(:,:,k);
            for i=1:length(coordinate)
                cut_picture(cut_coordinate(i,1),cut_coordinate(i,2))=img(coordinate(i,1),coordinate(i,2));
            end%����Ӧ��������ض�Ӧ
            cut_picture=cast(cut_picture,'uint8');
            B=zeros(5,5);
            D = padarray(cut_picture,[3 3],'replicate','both');%�������
            for i=4:h+3
                for j=4:w+3
                    if D(i,j)==0
                        no_zero=find(D(i-1:i+1,j-1:j+1)~=0);
                        [m,n]=size(no_zero);
                        if m~=0
                            B=D(i-1:i+1,j-1:j+1);
                        else
                            no_zero=find(D(i-2:i+2,j-2:j+2)~=0);
                            [m,n]=size(no_zero);
                            if m~=0
                                B=D(i-2:i+2,j-2:j+2);
                            else
                                no_zero=find(D(i-3:i+3,j-3:j+3)~=0);
                                B=D(i-3:i+3,j-3:j+3);
                            end%�����Ƕ�û�б����ĵ���д���
                        end
                        cut_picture2(i-3,j-3)=median(B(no_zero));%ԭû�б���ֵ�ɹ������ص㣬����Χ�������ص���λ�����棻
                    else
                        cut_picture2(i-3,j-3)=cut_picture(i-3,j-3);
                    end
                end
            end
            OutPicture(:,:,k)=cut_picture2;
        end%�����Ƕ�ͼ����ͨ�����д����ģ����ڵõ���ɫͼ��
        axes(handles.axes2);
        imshow(OutPicture),title('͸�ӱ任');
    end
end 
    

% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
textString = get(handles.resize,'String');

s = eval(textString);
set(handles.edit1,'String',s);



function resize_Callback(hObject, eventdata, handles)
% hObject    handle to resize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resize as text
%        str2double(get(hObject,'String')) returns contents of resize as a double


% --- Executes during object creation, after setting all properties.
function resize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in bianyuanjiance.
function bianyuanjiance_Callback(hObject, eventdata, handles)
% hObject    handle to bianyuanjiance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns bianyuanjiance contents as cell array
%        contents{get(hObject,'Value')} returns selected item from bianyuanjiance
global I;
I1 = rgb2gray(I);
e = get(hObject,'Value');
if e == 1
    BW1=edge(I1,'sobel');
    axes(handles.axes2);
    imshow(BW1),title('sobel���ӱ�Ե��ⷨ');
else
    if e == 2
        BW1=edge(I1,'prewitt');
        axes(handles.axes2);
        imshow(BW1),title('Prewitt���ӱ�Ե��ⷨ');
    end
    if e == 3
         BW1=edge(I1,'log');
        axes(handles.axes2);
        imshow(BW1),title('log���ӱ�Ե��ⷨ');
    end
    if e == 4
         BW1=edge(I1,'canny');
        axes(handles.axes2);
        imshow(BW1),title('canny���ӱ�Ե��ⷨ');
    end
end



% --- Executes during object creation, after setting all properties.
function bianyuanjiance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bianyuanjiance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in opresize.
function opresize_Callback(hObject, eventdata, handles)
% hObject    handle to opresize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns opresize contents as cell array
%        contents{get(hObject,'Value')} returns selected item from opresize
global I;
textString = get(handles.resize,'String');
s = eval(textString);
c = get(hObject,'Value');
%set(handles.resize,'String',s);

%input = get(handles.
if c == 1
    N = imresize(I,s,'nearest');
    axes(handles.axes2);
    imshow(N),title('���ڽ���������Ӧ����');
else
    if c == 2
        N = imresize(I,s,'bilinear');
        axes(handles.axes2);
        imshow(N),title('˫���Բ�ֵ��');
    end
    if c == 3
        N = imresize(I,s,'bicubic');
        axes(handles.axes2);
        imshow(N),title('˫���β�ֵ��');
    end
end
%set(handles.edit1,'String',s);


% --- Executes during object creation, after setting all properties.
%function opresize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to opresize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5
global I;
textString = get(handles.edit3,'String');
s = eval(textString);
c = get(hObject,'Value');
if c == 1
    N = imrotate(I,s,'nearest');
    axes(handles.axes2);
    imshow(N),title('���ڽ���������Ӧ����');
else
    if c == 2
        N = imrotate(I,s,'bilinear');
        axes(handles.axes2);
        imshow(N),title('˫���Բ�ֵ��');
    end
    if c == 3
        N = imrotate(I,s,'bicubic');
        axes(handles.axes2);
        imshow(N),title('˫���β�ֵ��');
    end
end

% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(gui); 
set(crop,'Visible','on'); 


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton7


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(gui); 
set(sift,'Visible','on'); 


% --------------------------------------------------------------------
function gray_Callback(hObject, eventdata, handles)
% hObject    handle to gray (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
x=rgb2gray(I);
axes(handles.axes2);
imshow(x),title('�Ҷ�ͼ');


% --------------------------------------------------------------------
function hist_Callback(hObject, eventdata, handles)
% hObject    handle to hist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
h=imhist(rgb2gray(I));
axes(handles.axes2);
bar(h),title('ֱ��ͼ');


% --------------------------------------------------------------------
function log_Callback(hObject, eventdata, handles)
% hObject    handle to log (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
BW1=edge(rgb2gray(I), 'log');
axes(handles.axes2);
imshow(BW1),title('Log���ӱ�Ե��ⷨ');

% --------------------------------------------------------------------
function canny_Callback(hObject, eventdata, handles)
% hObject    handle to canny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
BW1=edge(rgb2gray(I), 'canny');
axes(handles.axes2);
imshow(BW1),title('Canny���ӱ�Ե��ⷨ');


% --------------------------------------------------------------------
function histshow_Callback(hObject, eventdata, handles)
% hObject    handle to histshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I;
H = histeq(rgb2gray(I));
axes(handles.axes2);
imshow(H),title('ֱ��ͼ���⻯');


% --------------------------------------------------------------------
function Crop_Callback(hObject, eventdata, handles)
% hObject    handle to Crop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --------------------------------------------------------------------
close(gui); 
set(crop,'Visible','on'); 

function Sift_Callback(hObject, eventdata, handles)
% hObject    handle to Sift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(gui); 
set(sift,'Visible','on'); 


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
ha=axes('units','normalized','pos',[0 0 1 1]);
uistack(ha,'bottom');
ii=imread('jn.jpeg');
image(ii);
colormap gray
set(ha,'handlevisibility','off','visible','off');


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
f= imread('ts.png');
imshow(f);
fprintf('Begin to choose the color chip')
choose=true;
while choose
    imshow(f)
    dot=ginput(4);       %ȡ�ĸ��㣬���������ϣ����£�����,����
    y=[dot(1,1),dot(2,1),dot(3,1),dot(4,1)];        %�ĸ�ԭ����
    x=[dot(1,2),dot(2,2),dot(3,2),dot(4,2)];
    plot_x=[x,x(1)];
    plot_y=[y,y(1)];
    hold on
    plot(plot_y,plot_x,'r','LineWidth',2)
    hold off
    fprintf('Do you satisfy the target you chosen ,press 0 to rechose or press anything else to go\n');
    a=input('');
    if a~=0
        choose=false;
    end
end
w=round(max(dot(:,1))-min(dot(:,1)));
h=round(max(dot(:,2))-min(dot(:,2)));
%��ԭ�ı��λ���¾��θ�

%�������µĶ��㣬��ȡ�ľ���,Ҳ����������������״
%�����ԭͼ���Ǿ��Σ���ͼ���Ǵ�dot��ȡ�õĵ���ɵ������ı���.:)
Y=[1,1,w,w];     
X=[1,h,h,1];

B=[X(1),Y(1),X(2),Y(2),X(3),Y(3),X(4),Y(4)]';   %�任����ĸ����㣬�����ұߵ�ֵ
%�����ⷽ���飬���̵�ϵ��
A=[x(1),y(1),1,0,0,0,-X(1)*x(1),-X(1)*y(1);             
   0,0,0,x(1),y(1),1,-Y(1)*x(1),-Y(1)*y(1);
   x(2),y(2),1,0,0,0,-X(2)*x(2),-X(2)*y(2);
   0,0,0,x(2),y(2),1,-Y(2)*x(2),-Y(2)*y(2);
   x(3),y(3),1,0,0,0,-X(3)*x(3),-X(3)*y(3);
   0,0 ,0,x(3),y(3),1,-Y(3)*x(3),-Y(3)*y(3);
   x(4),y(4),1,0,0,0,-X(4)*x(4),-X(4)*y(4);
   0,0,0,x(4),y(4),1,-Y(4)*x(4),-Y(4)*y(4)];%���任���������ʽ
cut_picture=zeros(h,w);
OutPicture=zeros(h,w,3);
OutPicture=cast(OutPicture,'uint8');%���ͱ任Ϊuint8
fa=inv(A)*B;
fa=reshape([fa;1],[3,3]);%fa���Ǳ任����
cut=zeros(h+1,w+1);
BW=roipoly(f,y,x);%������ѡ������Ķ�ֵ��ͼ��cut
[coordinate_x,coordinate_y]=find(BW==1);%���ѡ�����������λ��
coordinate=[coordinate_x,coordinate_y,ones(length(coordinate_y),1)];%����z=1ֵ�Ա������߱任
cut=coordinate*fa;%��������仯
cut(:,1)=cut(:,1)./cut(:,3);
cut(:,2)=cut(:,2)./cut(:,3);%���ͼ���϶�Ӧ��x��yֵ
cut=floor(cut+eps);
cut(find(cut(:,1:2)==0))=1;%�߽�Ϊ��ĵ��Ϊ1��
cut_coordinate=cut(:,1:2);%��ñ任�������λ��
for k=1:3
    img=f(:,:,k);
    for i=1:length(coordinate)
        cut_picture(cut_coordinate(i,1),cut_coordinate(i,2))=img(coordinate(i,1),coordinate(i,2));
    end%����Ӧ��������ض�Ӧ
    cut_picture=cast(cut_picture,'uint8');
    B=zeros(5,5);
    D = padarray(cut_picture,[3 3],'replicate','both');%�������
    for i=4:h+3
        for j=4:w+3
            if D(i,j)==0
                no_zero=find(D(i-1:i+1,j-1:j+1)~=0);
                [m,n]=size(no_zero);
                if m~=0
                     B=D(i-1:i+1,j-1:j+1);
                else
                    no_zero=find(D(i-2:i+2,j-2:j+2)~=0);
                    [m,n]=size(no_zero);
                    if m~=0
                        B=D(i-2:i+2,j-2:j+2);
                    else
                         no_zero=find(D(i-3:i+3,j-3:j+3)~=0);
                         B=D(i-3:i+3,j-3:j+3);
                    end%�����Ƕ�û�б����ĵ���д���
                end
                cut_picture2(i-3,j-3)=median(B(no_zero));%ԭû�б���ֵ�ɹ������ص㣬����Χ�������ص���λ�����棻
            else
               cut_picture2(i-3,j-3)=cut_picture(i-3,j-3);
            end
        end
    end
    OutPicture(:,:,k)=cut_picture2;
end%�����Ƕ�ͼ����ͨ�����д����ģ����ڵõ���ɫͼ��
imshow(OutPicture);
